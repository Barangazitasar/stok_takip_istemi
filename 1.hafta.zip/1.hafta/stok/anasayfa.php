<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}
$kullanici_adi = $_SESSION['kullanici'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hoş Geldiniz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9f0f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .kutu {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .kutu h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .kutu p {
            margin-bottom: 30px;
        }

        .kutu a {
            display: block;
            margin: 10px 0;
            padding: 12px 25px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .kutu a:hover {
            background-color: #0056b3;
        }

        .kutu a.green {
            background-color: #28a745;
        }

        .kutu a.green:hover {
            background-color: #1e7e34;
        }

        .kutu a.red {
            background-color: #dc3545;
        }

        .kutu a.red:hover {
            background-color: #bd2130;
        }
    </style>
</head>
<body>
    <div class="kutu">
        <h2>Hoş geldin, <?php echo htmlspecialchars($kullanici_adi); ?>!</h2>
        <p>Stok takip sistemine başarıyla giriş yaptınız.</p>

        <a href="urunler.php">📦 Ürünleri Görüntüle</a>
        <a href="stok_hareketleri.php">📥📤 Stok Giriş / Çıkış</a>
        <a href="raporlar.php" class="green">📊 Grafiksel Raporlar</a>

        <?php if (isset($_SESSION['yetki']) && $_SESSION['yetki'] === 'yonetici'): ?>
            <a href="yonetici_paneli.php">🛠 Yönetici Paneli</a>
        <?php endif; ?>

        <a href="cikis.php" class="red">🚪 Çıkış Yap</a>
    </div>
</body>
</html>
