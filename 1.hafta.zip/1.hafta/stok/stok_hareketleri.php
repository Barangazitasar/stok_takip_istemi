<?php
session_start();
include 'baglanti.php';

// Giriş kontrolü
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Ürünleri çek
$urunler = $baglanti->query("SELECT * FROM stok ORDER BY urun_adi ASC")->fetchAll(PDO::FETCH_ASSOC);

// Giriş veya çıkış işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $urun_id = $_POST['urun_id'];
    $miktar = intval($_POST['miktar']);
    $hareket = $_POST['hareket'];

    // Mevcut stok bilgisi
    $urun = $baglanti->prepare("SELECT miktar FROM stok WHERE id = ?");
    $urun->execute([$urun_id]);
    $stok = $urun->fetchColumn();

    if ($hareket === 'giris') {
        $yeniStok = $stok + $miktar;
    } elseif ($hareket === 'cikis') {
        if ($stok < $miktar) {
            $hata = "Stokta yeterli miktar yok!";
        } else {
            $yeniStok = $stok - $miktar;
        }
    }

    if (!isset($hata)) {
        // Güncelleme
        $guncelle = $baglanti->prepare("UPDATE stok SET miktar = ? WHERE id = ?");
        $guncelle->execute([$yeniStok, $urun_id]);

        // Hareket kaydı (log)
        $log = $baglanti->prepare("INSERT INTO hareketler (urun_id, hareket_tipi, miktar) VALUES (?, ?, ?)");
        $log->execute([$urun_id, $hareket, $miktar]);

        $mesaj = ucfirst($hareket) . " işlemi başarılı.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stok Giriş / Çıkış</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f5;
            padding: 40px;
        }

        .kutu {
            background-color: #fff;
            max-width: 500px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
        }

        form select, form input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .mesaj {
            text-align: center;
            margin-bottom: 20px;
            color: green;
        }

        .hata {
            text-align: center;
            margin-bottom: 20px;
            color: red;
        }

        .geri-link {
            text-align: center;
            margin-top: 20px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="kutu">
        <h2>Stok Giriş / Çıkış</h2>
        <?php if (isset($mesaj)) echo "<div class='mesaj'>$mesaj</div>"; ?>
        <?php if (isset($hata)) echo "<div class='hata'>$hata</div>"; ?>
        <form method="post">
            <label>Ürün Seç:</label>
            <select name="urun_id" required>
                <option value="">-- Seçiniz --</option>
                <?php foreach ($urunler as $urun): ?>
                    <option value="<?php echo $urun['id']; ?>">
                        <?php echo $urun['urun_adi'] . " (" . $urun['miktar'] . " " . $urun['birim'] . ")"; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>İşlem Tipi:</label>
            <select name="hareket" required>
                <option value="giris">Stok Girişi</option>
                <option value="cikis">Stok Çıkışı</option>
            </select>

            <label>Miktar:</label>
            <input type="number" name="miktar" min="1" required>

            <button type="submit">İşlemi Uygula</button>
        </form>

        <div class="geri-link">
            <a href="anasayfa.php">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>
</html>
