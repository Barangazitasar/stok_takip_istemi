<?php
session_start();
include 'baglanti.php';

// Giriş kontrolü
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Veriler:
$toplamUrun = $baglanti->query("SELECT COUNT(*) FROM stok")->fetchColumn();
$toplamStok = $baglanti->query("SELECT SUM(miktar) FROM stok")->fetchColumn();
$kategoriSayilari = $baglanti->query("SELECT kategori, COUNT(*) as adet FROM stok GROUP BY kategori")->fetchAll(PDO::FETCH_ASSOC);
$enCokStok = $baglanti->query("SELECT * FROM stok ORDER BY miktar DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stok Raporları</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f9;
            padding: 40px;
        }

        .kutu {
            background-color: #fff;
            max-width: 600px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .veri {
            margin-bottom: 20px;
            font-size: 18px;
        }

        .kategori-liste {
            padding-left: 20px;
        }

        .geri-link {
            text-align: center;
            margin-top: 30px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="kutu">
        <h2>Stok Raporları</h2>

        <div class="veri">📦 <strong>Toplam Ürün:</strong> <?php echo $toplamUrun; ?></div>
        <div class="veri">📊 <strong>Toplam Stok Miktarı:</strong> <?php echo $toplamStok; ?></div>

        <div class="veri">
            🗂️ <strong>Kategoriye Göre Ürün Sayısı:</strong>
            <ul class="kategori-liste">
                <?php foreach ($kategoriSayilari as $kategori): ?>
                    <li><?php echo htmlspecialchars($kategori['kategori']) . ": " . $kategori['adet']; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="veri">🏆 <strong>En Fazla Stoğa Sahip Ürün:</strong>
            <?php echo htmlspecialchars($enCokStok['urun_adi']) . " (" . $enCokStok['miktar'] . " " . $enCokStok['birim'] . ")"; ?>
        </div>

        <div class="geri-link">
            <a href="anasayfa.php">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>
</html>
