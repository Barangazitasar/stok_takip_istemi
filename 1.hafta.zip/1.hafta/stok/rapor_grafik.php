<?php
session_start();
include 'baglanti.php';

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Veriyi al (kategoriye göre sayım)
$sorgu = $baglanti->query("SELECT kategori, COUNT(*) as adet FROM stok GROUP BY kategori")->fetchAll(PDO::FETCH_ASSOC);

// Kategorileri ve sayılarını ayrı dizilere ayıralım
$kategoriler = [];
$sayilar = [];

foreach ($sorgu as $row) {
    $kategoriler[] = $row['kategori'] ?: 'Belirtilmemiş';
    $sayilar[] = $row['adet'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Rapor - Grafik</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            padding: 40px;
            text-align: center;
        }

        .grafik-kutu {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        .geri-link {
            margin-top: 30px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="grafik-kutu">
        <h2>📊 Kategoriye Göre Ürün Dağılımı</h2>
        <canvas id="kategoriChart" width="400" height="400"></canvas>

        <script>
            const ctx = document.getElementById('kategoriChart').getContext('2d');
            const kategoriChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode($kategoriler); ?>,
                    datasets: [{
                        label: 'Ürün Sayısı',
                        data: <?php echo json_encode($sayilar); ?>,
                        backgroundColor: [
                            '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'
                        ],
                        borderColor: '#fff',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        </script>

        <div class="geri-link">
            <a href="anasayfa.php">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>
</html>
