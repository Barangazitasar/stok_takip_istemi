<?php
session_start();
include 'baglanti.php';

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Gün bazında stok giriş ve çıkış verilerini grupla
$veri = $baglanti->query("
    SELECT 
        DATE(tarih) as gun,
        SUM(CASE WHEN hareket_tipi = 'giris' THEN miktar ELSE 0 END) as giris_toplam,
        SUM(CASE WHEN hareket_tipi = 'cikis' THEN miktar ELSE 0 END) as cikis_toplam
    FROM hareketler
    GROUP BY DATE(tarih)
    ORDER BY DATE(tarih) ASC
")->fetchAll(PDO::FETCH_ASSOC);

$tarihler = [];
$girisler = [];
$cikislar = [];

foreach ($veri as $v) {
    $tarihler[] = $v['gun'];
    $girisler[] = $v['giris_toplam'];
    $cikislar[] = $v['cikis_toplam'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Stok Giriş / Çıkış Grafiği</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            padding: 40px;
            text-align: center;
        }

        .grafik-kutu {
            max-width: 900px;
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        .geri-link {
            margin-top: 30px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="grafik-kutu">
        <h2>📈 Stok Giriş / Çıkış Tarihsel Grafik</h2>
        <canvas id="lineChart" height="400"></canvas>

        <script>
            const ctx = document.getElementById('lineChart').getContext('2d');
            const lineChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($tarihler); ?>,
                    datasets: [
                        {
                            label: 'Giriş',
                            data: <?php echo json_encode($girisler); ?>,
                            borderColor: '#28a745',
                            backgroundColor: '#28a74533',
                            tension: 0.3
                        },
                        {
                            label: 'Çıkış',
                            data: <?php echo json_encode($cikislar); ?>,
                            borderColor: '#dc3545',
                            backgroundColor: '#dc354533',
                            tension: 0.3
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>

        <div class="geri-link">
            <a href="anasayfa.php">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>
</html>
