<?php
// Hata gösterimi (geliştirme sırasında kullan)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabanı bilgileri
$host = "localhost";
$dbname = "stok_takip"; // phpMyAdmin'de bu isimle veritabanı var mı?
$kullanici = "root";
$sifre = ""; // XAMPP'de şifre genellikle boş olur

try {
    $baglanti = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $kullanici, $sifre);
    $baglanti->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Veritabanı bağlantısı başarılı!"; // İstersen test için açabilirsin
} catch (PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}
?>
