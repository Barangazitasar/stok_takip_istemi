<?php
session_start();
include 'baglanti.php';

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Ürün ekleme
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ekle'])) {
    $urun_adi = $_POST['urun_adi'];
    $kategori = $_POST['kategori'];
    $miktar = $_POST['miktar'];
    $birim = $_POST['birim'];
    $fiyat = $_POST['fiyat'];

    $ekle = $baglanti->prepare("INSERT INTO stok (urun_adi, kategori, miktar, birim, fiyat) VALUES (?, ?, ?, ?, ?)");
    $ekle->execute([$urun_adi, $kategori, $miktar, $birim, $fiyat]);
}

// Arama filtresi
$arama = isset($_GET['arama']) ? trim($_GET['arama']) : '';

if ($arama != '') {
    $sorgu = $baglanti->prepare("SELECT * FROM stok WHERE urun_adi LIKE ? OR kategori LIKE ? ORDER BY id DESC");
    $sorgu->execute(["%$arama%", "%$arama%"]);
    $urunler = $sorgu->fetchAll(PDO::FETCH_ASSOC);
} else {
    $urunler = $baglanti->query("SELECT * FROM stok ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
}

// Kritik stok kontrolü
$kritik_urunler = array_filter($urunler, function($u) {
    return $u['miktar'] <= 10;
});
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ürün Yönetimi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f5;
            padding: 40px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .form-kutu {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            margin: auto;
            max-width: 500px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .form-kutu input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form-kutu button {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-kutu button:hover {
            background-color: #218838;
        }

        .arama-form {
            text-align: right;
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .arama-form input[type="text"] {
            padding: 8px;
            width: 200px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .arama-form input[type="submit"] {
            padding: 8px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 5px;
            cursor: pointer;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            background: #fff;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .aksiyon a {
            text-decoration: none;
            margin: 0 5px;
            font-size: 18px;
        }

        .aksiyon a:hover {
            opacity: 0.7;
        }

        .geri-link {
            text-align: center;
            margin-top: 20px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }

        .uyari-kutu {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h2>Yeni Ürün Ekle</h2>
    <div class="form-kutu">
        <form method="post" action="">
            <input type="text" name="urun_adi" placeholder="Ürün Adı" required>
            <input type="text" name="kategori" placeholder="Kategori">
            <input type="number" name="miktar" placeholder="Miktar" required>
            <input type="text" name="birim" placeholder="Birim (adet, kg, litre)">
            <input type="text" name="fiyat" placeholder="Fiyat">
            <button type="submit" name="ekle">Ürün Ekle</button>
        </form>
    </div>

    <h2>Ürün Listesi</h2>

    <div class="arama-form">
        <form method="get">
            <input type="text" name="arama" placeholder="Ürün adı / kategori" value="<?php echo htmlspecialchars($arama); ?>">
            <input type="submit" value="Ara">
        </form>
    </div>

    <?php if (count($kritik_urunler) > 0): ?>
        <div class="uyari-kutu">
            ⚠️ <strong>Kritik Stok Uyarısı:</strong><br>
            <?php foreach ($kritik_urunler as $k): ?>
                - <?php echo htmlspecialchars($k['urun_adi']); ?> (<?php echo $k['miktar']; ?> <?php echo $k['birim']; ?>)<br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Adı</th>
            <th>Kategori</th>
            <th>Miktar</th>
            <th>Birim</th>
            <th>Fiyat</th>
            <th>Eklenme Tarihi</th>
            <th>İşlem</th>
        </tr>
        <?php foreach ($urunler as $urun): ?>
        <tr>
            <td><?php echo $urun['id']; ?></td>
            <td><?php echo htmlspecialchars($urun['urun_adi']); ?></td>
            <td><?php echo htmlspecialchars($urun['kategori']); ?></td>
            <td>
                <?php
                    if ($urun['miktar'] <= 10) {
                        echo "<span style='color:red; font-weight:bold;'>{$urun['miktar']} ⚠️</span>";
                    } else {
                        echo $urun['miktar'];
                    }
                ?>
            </td>
            <td><?php echo htmlspecialchars($urun['birim']); ?></td>
            <td><?php echo $urun['fiyat']; ?></td>
            <td><?php echo $urun['eklenme_tarihi']; ?></td>
            <td class="aksiyon">
                <a href="guncelle.php?id=<?php echo $urun['id']; ?>">📝</a>
                <a href="sil.php?id=<?php echo $urun['id']; ?>" onclick="return confirm('Silmek istediğinize emin misiniz?');">❌</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="geri-link">
        <a href="anasayfa.php">← Ana Sayfaya Dön</a>
    </div>
</body>
</html>
