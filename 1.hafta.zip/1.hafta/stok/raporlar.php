<?php
session_start();

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Grafiksel Raporlar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f5;
            padding: 40px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 30px;
        }

        .kutu {
            max-width: 500px;
            margin: 20px auto;
            background-color: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .kutu a {
            display: block;
            margin: 10px 0;
            padding: 12px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .kutu a:hover {
            background-color: #0056b3;
        }

        .geri-link {
            margin-top: 30px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <h2>📊 Grafiksel Raporlar</h2>

    <div class="kutu">
        <a href="rapor_grafik.php">Kategoriye Göre Ürün Dağılımı</a>
        <a href="stok_miktari_grafik.php">Ürün Bazlı Stok Miktarları</a>
        <a href="stok_grafik_tarih.php">Stok Giriş / Çıkış Zaman Grafiği</a>
    </div>

    <div class="geri-link">
        <a href="anasayfa.php">← Ana Sayfaya Dön</a>
    </div>

</body>
</html>
