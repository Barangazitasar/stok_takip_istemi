<?php
include 'baglanti.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sil = $baglanti->prepare("DELETE FROM stok WHERE id = ?");
    $sil->execute([$id]);
}

header("Location: urunler.php");
exit;
