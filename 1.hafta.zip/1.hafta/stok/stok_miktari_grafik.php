<?php
session_start();
include 'baglanti.php';

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Veritabanından ürün adları ve stok miktarlarını çek
$sorgu = $baglanti->query("SELECT urun_adi, miktar FROM stok ORDER BY miktar DESC")->fetchAll(PDO::FETCH_ASSOC);

$urunler = [];
$miktarlar = [];

foreach ($sorgu as $row) {
    $urunler[] = $row['urun_adi'];
    $miktarlar[] = $row['miktar'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ürün Bazlı Stok Miktarları</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            padding: 40px;
            text-align: center;
        }

        .grafik-kutu {
            max-width: 900px;
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        .geri-link {
            margin-top: 30px;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="grafik-kutu">
        <h2>📦 Ürün Bazlı Stok Miktarları</h2>
        <canvas id="stokChart" height="400"></canvas>

        <script>
            const ctx = document.getElementById('stokChart').getContext('2d');
            const stokChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($urunler); ?>,
                    datasets: [{
                        label: 'Stok Miktarı',
                        data: <?php echo json_encode($miktarlar); ?>,
                        backgroundColor: '#36b9cc',
                        borderColor: '#2c9faf',
                        borderWidth: 1
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        x: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>

        <div class="geri-link">
            <a href="anasayfa.php">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>
</html>
