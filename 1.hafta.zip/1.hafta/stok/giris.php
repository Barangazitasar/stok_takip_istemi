<?php
session_start();
include 'baglanti.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullanici_adi = $_POST['kullanici_adi'];
    $sifre = $_POST['sifre'];

    $sorgu = $baglanti->prepare("SELECT * FROM kullanicilar WHERE kullanici_adi = ? AND sifre = ?");
    $sorgu->execute([$kullanici_adi, $sifre]);
    $kullanici = $sorgu->fetch();

    if ($kullanici) {
        $_SESSION['kullanici'] = $kullanici['kullanici_adi'];
        $_SESSION['yetki'] = $kullanici['yetki'];

        if (isset($_POST['yonetici_giris']) && $kullanici['yetki'] === 'yonetici') {
            header("Location: yonetici_paneli.php");
        } elseif (isset($_POST['kullanici_giris'])) {
            header("Location: anasayfa.php");
        } else {
            $hata = "Yetkisiz giriş!";
        }

        exit;
    } else {
        $hata = "Kullanıcı adı veya şifre hatalı!";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Giriş Yap</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f1f1f1;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .giris-kutusu {
        background-color: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        width: 300px;
    }

    .giris-kutusu h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #333;
    }

    .giris-kutusu label {
        display: block;
        margin-bottom: 5px;
        color: #444;
        font-weight: bold;
    }

    .giris-kutusu input[type="text"],
    .giris-kutusu input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .giris-kutusu input[type="submit"] {
        width: 100%;
        background-color: #007bff;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .giris-kutusu input[type="submit"]:hover {
        background-color: #0056b3;
    }

    .hata {
        color: red;
        text-align: center;
        margin-bottom: 10px;
    }
</style>

</head>
<body>
    <div class="giris-kutusu">
        <h2>Stok Takip - Giriş</h2>
        <?php if (isset($hata)) echo "<p class='hata'>$hata</p>"; ?>
        <form method="post" action="">
            <label>Kullanıcı Adı:</label>
            <input type="text" name="kullanici_adi" required>
            <label>Şifre:</label>
            <input type="password" name="sifre" required>
            <input type="submit" name="kullanici_giris" value="Giriş Yap">
            <input type="submit" name="yonetici_giris" value="Yönetici Girişi">
        </form>
    </div>
</body>

</html>
