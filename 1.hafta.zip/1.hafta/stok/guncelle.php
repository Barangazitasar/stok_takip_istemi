<?php
include 'baglanti.php';

if (!isset($_GET['id'])) {
    header("Location: urunler.php");
    exit;
}

$id = $_GET['id'];

// Güncelleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $urun_adi = $_POST['urun_adi'];
    $kategori = $_POST['kategori'];
    $miktar = $_POST['miktar'];
    $birim = $_POST['birim'];
    $fiyat = $_POST['fiyat'];

    $guncelle = $baglanti->prepare("UPDATE stok SET urun_adi=?, kategori=?, miktar=?, birim=?, fiyat=? WHERE id=?");
    $guncelle->execute([$urun_adi, $kategori, $miktar, $birim, $fiyat, $id]);

    header("Location: urunler.php");
    exit;
}

// Mevcut ürünü çek
$sorgu = $baglanti->prepare("SELECT * FROM stok WHERE id = ?");
$sorgu->execute([$id]);
$urun = $sorgu->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ürün Güncelle</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f5;
            padding: 40px;
        }

        .kutu {
            background: #fff;
            max-width: 500px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        .kutu h2 {
            text-align: center;
        }

        input {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="kutu">
        <h2>Ürün Güncelle</h2>
        <form method="post">
            <input type="text" name="urun_adi" value="<?php echo $urun['urun_adi']; ?>" required>
            <input type="text" name="kategori" value="<?php echo $urun['kategori']; ?>">
            <input type="number" name="miktar" value="<?php echo $urun['miktar']; ?>" required>
            <input type="text" name="birim" value="<?php echo $urun['birim']; ?>">
            <input type="text" name="fiyat" value="<?php echo $urun['fiyat']; ?>">
            <button type="submit">Kaydet</button>
        </form>
    </div>
</body>
</html>
