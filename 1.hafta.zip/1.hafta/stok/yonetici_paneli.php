<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'baglanti.php';

if (!isset($_SESSION['kullanici']) || $_SESSION['yetki'] !== 'yonetici') {
    header("Location: giris.php");
    exit;
}

// Yeni kullanıcı ekleme
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ekle'])) {
    $yeni_kullanici = $_POST['kullanici_adi'];
    $yeni_sifre = $_POST['sifre'];
    $yeni_yetki = $_POST['yetki'];

    $kontrol = $baglanti->prepare("SELECT * FROM kullanicilar WHERE kullanici_adi = ?");
    $kontrol->execute([$yeni_kullanici]);

    if ($kontrol->rowCount() > 0) {
        $ekle_hata = "Bu kullanıcı adı zaten kayıtlı.";
    } else {
        $ekle = $baglanti->prepare("INSERT INTO kullanicilar (kullanici_adi, sifre, yetki) VALUES (?, ?, ?)");
        $ekle->execute([$yeni_kullanici, $yeni_sifre, $yeni_yetki]);
        header("Location: yonetici_paneli.php");
        exit;
    }
}

// Kullanıcı silme
if (isset($_GET['sil'])) {
    $sil_id = $_GET['sil'];
    $kontrol = $baglanti->prepare("SELECT yetki FROM kullanicilar WHERE id = ?");
    $kontrol->execute([$sil_id]);
    $kullanici = $kontrol->fetch();

    if ($kullanici && $kullanici['yetki'] !== 'yonetici') {
        $sil = $baglanti->prepare("DELETE FROM kullanicilar WHERE id = ?");
        $sil->execute([$sil_id]);
        header("Location: yonetici_paneli.php");
        exit;
    }
}

// Yetki güncelleme
if (isset($_GET['yetki_degistir']) && isset($_GET['yeni_yetki'])) {
    $id = $_GET['yetki_degistir'];
    $yeni_yetki = $_GET['yeni_yetki'];

    $kontrol = $baglanti->prepare("SELECT yetki FROM kullanicilar WHERE id = ?");
    $kontrol->execute([$id]);
    $mevcut = $kontrol->fetch();

    if ($mevcut && $mevcut['yetki'] !== 'yonetici') {
        $guncelle = $baglanti->prepare("UPDATE kullanicilar SET yetki = ? WHERE id = ?");
        $guncelle->execute([$yeni_yetki, $id]);
        header("Location: yonetici_paneli.php");
        exit;
    }
}

// Şifre güncelleme
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sifre_degistir'])) {
    $sifre_id = $_POST['kullanici_id'];
    $yeni_sifre = $_POST['yeni_sifre'];

    $guncelle = $baglanti->prepare("UPDATE kullanicilar SET sifre = ? WHERE id = ?");
    $guncelle->execute([$yeni_sifre, $sifre_id]);
    $sifre_basarili = "Şifre güncellendi.";
}
$kullanicilar = $baglanti->query("SELECT * FROM kullanicilar ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Yönetici Paneli</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f2f5;
            padding: 40px;
        }

        .panel {
            max-width: 1000px;
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2, h3 {
            text-align: center;
            color: #333;
        }

        .form {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            flex-wrap: wrap;
            justify-content: center;
        }

        .form input, .form select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            width: 200px;
        }

        .form input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            width: auto;
            padding: 10px 20px;
        }

        .form input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .sil-link {
            color: red;
            text-decoration: none;
        }

        .sil-link:hover {
            text-decoration: underline;
        }

        .geri-link {
            margin-top: 30px;
            text-align: center;
        }

        .geri-link a {
            color: #007bff;
            text-decoration: none;
        }

        .geri-link a:hover {
            text-decoration: underline;
        }

        .sifre-form input {
            width: 120px;
            margin: 5px;
        }

        .sifre-form input[type="submit"] {
            width: auto;
        }
    </style>
</head>
<body>
    <div class="panel">
        <h2>Yönetici Paneli</h2>

        <h3>Yeni Kullanıcı Ekle</h3>
        <?php if (isset($ekle_hata)) echo "<div class='message' style='color:red;'>$ekle_hata</div>"; ?>
        <?php if (isset($ekle_basarili)) echo "<div class='message' style='color:green;'>$ekle_basarili</div>"; ?>
        <?php if (isset($sifre_basarili)) echo "<div class='message' style='color:green;'>$sifre_basarili</div>"; ?>

        <form method="post" class="form">
            <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
            <input type="password" name="sifre" placeholder="Şifre" required>
            <select name="yetki" required>
                <option value="">Yetki Seç</option>
                <option value="kullanici">Kullanıcı</option>
                <option value="yonetici">Yönetici</option>
            </select>
            <input type="submit" name="ekle" value="Kullanıcı Ekle">
        </form>

        <h3>Kullanıcı Listesi</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Kullanıcı Adı</th>
                <th>Yetki</th>
                <th>İşlemler</th>
                <th>Şifre Değiştir</th>
            </tr>
            <?php foreach ($kullanicilar as $k): ?>
                <tr>
                    <td><?php echo $k['id']; ?></td>
                    <td><?php echo htmlspecialchars($k['kullanici_adi']); ?></td>
                    <td><?php echo $k['yetki']; ?></td>
                    <td>
                        <?php if ($k['yetki'] !== 'yonetici'): ?>
                            <a class="sil-link" href="?sil=<?php echo $k['id']; ?>" onclick="return confirm('Kullanıcı silinsin mi?')">Sil</a><br>
                            <?php if ($k['yetki'] === 'kullanici'): ?>
                                <a href="?yetki_degistir=<?php echo $k['id']; ?>&yeni_yetki=yonetici">Yönetici Yap</a>
                            <?php else: ?>
                                <a href="?yetki_degistir=<?php echo $k['id']; ?>&yeni_yetki=kullanici">Kullanıcı Yap</a>
                            <?php endif; ?>
                        <?php else: ?>
                            🔒
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="post" class="sifre-form">
                            <input type="hidden" name="kullanici_id" value="<?php echo $k['id']; ?>">
                            <input type="text" name="yeni_sifre" placeholder="Yeni Şifre" required>
                            <input type="submit" name="sifre_degistir" value="Güncelle">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

        <div class="geri-link">
            <a href="anasayfa.php">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>
</html>
