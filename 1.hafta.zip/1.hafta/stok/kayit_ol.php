<?php
include 'baglanti.php';

$mesaj = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullanici_adi = $_POST['kullanici_adi'];
    $sifre = $_POST['sifre'];

    // Aynı kullanıcı adı var mı kontrolü
    $kontrol = $baglanti->prepare("SELECT * FROM kullanicilar WHERE kullanici_adi = ?");
    $kontrol->execute([$kullanici_adi]);

    if ($kontrol->rowCount() > 0) {
        $mesaj = "Bu kullanıcı adı zaten kullanılıyor.";
    } else {
        // Yeni kullanıcı ekle (yetki: kullanici)
        $ekle = $baglanti->prepare("INSERT INTO kullanicilar (kullanici_adi, sifre, yetki) VALUES (?, ?, 'kullanici')");
        $ekle->execute([$kullanici_adi, $sifre]);

        $mesaj = "Kayıt başarılı! Giriş yapabilirsiniz.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kayıt Ol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f1f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .kayit-kutusu {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .kayit-kutusu h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .kayit-kutusu input[type="text"],
        .kayit-kutusu input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .kayit-kutusu input[type="submit"] {
            width: 100%;
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .kayit-kutusu input[type="submit"]:hover {
            background-color: #218838;
        }

        .mesaj {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="kayit-kutusu">
        <h2>Kayıt Ol</h2>
        <?php if ($mesaj) echo "<p class='mesaj'>$mesaj</p>"; ?>
        <form method="post" action="">
            <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
            <input type="password" name="sifre" placeholder="Şifre" required>
            <input type="submit" value="Kayıt Ol">
        </form>
    </div>
</body>
</html>
