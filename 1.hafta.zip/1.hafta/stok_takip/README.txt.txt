Stok Takip Uygulaması - Açıklama ve Yapılanlar

Hazırlayan: baran gazi taşar

Bu uygulamayı depodaki ürün miktarlarını ve hareketlerini izlemek amacıyla HTML CSS ve Flask kullanarak yaptım

Klasör Yapısı:
- app.py → Flask uygulaması
- templates/ → HTML sayfaları (index.html, dashboard.html, urunler.html, hareketler.html)
- static/style.css → CSS dosyası

Kullanılan Sayfalar:
1. index.html → Giriş formu
2. dashboard.html → Ana panel
3. urunler.html → Ürün listeleme ve ekleme
4. hareketler.html → Giriş/çıkış işlemleri

Rotalar (Flask):
- / → index
- /dashboard → yönetim paneli
- /urunler → ürün sayfası
- /hareketler → depo hareketleri

CSS: Ayrı dosyada yazıldı ve static/ içinde style.css olarak yer aldı.

Not: ödevim saddece html ve css vardır veri kaydı yapılmadı daha.
